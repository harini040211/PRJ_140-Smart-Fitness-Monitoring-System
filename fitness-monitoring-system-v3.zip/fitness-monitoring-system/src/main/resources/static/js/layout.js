// Injects the desktop sidebar + mobile topbar + mobile bottom nav.
// Each page sets: <body data-page="dashboard"> to highlight the right link.

const NAV_ITEMS = [
  { key: "dashboard", href: "dashboard.html", icon: "🏠", label: "Dashboard" },
  { key: "profile", href: "profile.html", icon: "👤", label: "Profile" },
  { key: "workouts", href: "workout.html", icon: "🏋️", label: "Workouts" },
  { key: "diet", href: "diet.html", icon: "🍽️", label: "Diet" },
];

function renderLayout() {
  const page = document.body.dataset.page || "";
  const fullName = getFullName();
  const initial = fullName.charAt(0).toUpperCase();

  const navLinks = (variant) => NAV_ITEMS.map(item => `
    <a href="${item.href}" class="${page === item.key ? 'active' : ''}">
      <span class="ic">${item.icon}</span>${variant === 'bottom' ? '' : item.label}
    </a>`).join("");

  const sidebarHtml = `
    <div class="sidebar">
      <div class="brand">Fitness<span class="dot">Monitor</span></div>
      <nav>${navLinks('side')}</nav>
      <div class="sidebar-user">
        <div class="avatar">${initial}</div>
        <div style="flex:1;">
          <div class="name">${fullName}</div>
          <a href="#" class="logout-link" onclick="logout()">Log out</a>
        </div>
      </div>
    </div>`;

  const topbarHtml = `
    <div class="topbar-mobile">
      <div class="brand">Fitness<span class="dot">Monitor</span></div>
      <div class="user-chip">${fullName}</div>
    </div>`;

  const bottomNavHtml = `
    <div class="bottom-nav">
      ${navLinks('bottom')}
      <a href="#" onclick="logout()"><span class="ic">🚪</span></a>
    </div>`;

  document.getElementById("sidebar-root").innerHTML = sidebarHtml;
  document.getElementById("topbar-root").innerHTML = topbarHtml;
  document.getElementById("bottomnav-root").innerHTML = bottomNavHtml;
}

document.addEventListener("DOMContentLoaded", () => {
  requireLogin();
  renderLayout();
});
