// Base URL of the Spring Boot backend. Same host/port when served from
// /static, so a relative path is enough.
const API_BASE = "/api";

async function apiPost(path, body) {
  const res = await fetch(API_BASE + path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json();
  if (!res.ok || data.success === false) {
    throw new Error(data.message || "Request failed");
  }
  return data.data;
}

async function apiGet(path) {
  const res = await fetch(API_BASE + path);
  const data = await res.json();
  if (!res.ok || data.success === false) {
    throw new Error(data.message || "Request failed");
  }
  return data.data;
}

// ---- Very small "session" helper (Review-2 scope: no JWT yet) ----
function saveSession(userId, fullName) {
  localStorage.setItem("fms_userId", userId);
  localStorage.setItem("fms_fullName", fullName);
}
function getUserId() {
  // Stored as a plain string in localStorage; convert to a number here so
  // it serializes as a JSON number (matching the Long userId field on the
  // backend entities) rather than a quoted string.
  const id = localStorage.getItem("fms_userId");
  return id ? Number(id) : null;
}
function getFullName() {
  return localStorage.getItem("fms_fullName") || "User";
}
function requireLogin() {
  if (!getUserId()) {
    window.location.href = "login.html";
  }
}
function logout() {
  localStorage.removeItem("fms_userId");
  localStorage.removeItem("fms_fullName");
  window.location.href = "login.html";
}

function showAlert(elId, message, type) {
  const el = document.getElementById(elId);
  el.textContent = message;
  el.className = "alert " + type;
}
