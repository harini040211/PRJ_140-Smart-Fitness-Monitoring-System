// Food database - per single serving. Calories/macros are always computed
// from (food x servings), never typed in directly by the user.
const FOODS = [
  { name: "Oats", icon: "🥣", category: "Breakfast", serving: "40g", calories: 150, protein: 5, carbs: 27, fat: 3 },
  { name: "Boiled Eggs (2)", icon: "🥚", category: "Breakfast", serving: "2 eggs", calories: 155, protein: 13, carbs: 1, fat: 11 },
  { name: "Idli (2 pcs)", icon: "🍚", category: "Breakfast", serving: "2 pcs", calories: 120, protein: 4, carbs: 24, fat: 0.5 },
  { name: "Dosa", icon: "🫓", category: "Breakfast", serving: "1 piece", calories: 168, protein: 4, carbs: 29, fat: 4 },
  { name: "Chicken Breast", icon: "🍗", category: "Protein", serving: "100g", calories: 165, protein: 31, carbs: 0, fat: 3.6 },
  { name: "Paneer", icon: "🧀", category: "Protein", serving: "100g", calories: 265, protein: 18, carbs: 6, fat: 20 },
  { name: "Fish (Grilled)", icon: "🐟", category: "Protein", serving: "100g", calories: 140, protein: 26, carbs: 0, fat: 4 },
  { name: "Rice (Cooked)", icon: "🍚", category: "Grains", serving: "1 cup", calories: 205, protein: 4.3, carbs: 45, fat: 0.4 },
  { name: "Roti", icon: "🫓", category: "Grains", serving: "1 piece", calories: 104, protein: 3, carbs: 18, fat: 2.5 },
  { name: "Brown Bread (2 slices)", icon: "🍞", category: "Grains", serving: "2 slices", calories: 160, protein: 6, carbs: 28, fat: 2 },
  { name: "Mixed Salad", icon: "🥗", category: "Vegetables", serving: "1 bowl", calories: 80, protein: 3, carbs: 12, fat: 2 },
  { name: "Steamed Vegetables", icon: "🥦", category: "Vegetables", serving: "1 cup", calories: 60, protein: 3, carbs: 11, fat: 0.5 },
  { name: "Banana", icon: "🍌", category: "Fruits", serving: "1 medium", calories: 105, protein: 1.3, carbs: 27, fat: 0.4 },
  { name: "Apple", icon: "🍎", category: "Fruits", serving: "1 medium", calories: 95, protein: 0.5, carbs: 25, fat: 0.3 },
  { name: "Mixed Fruit Bowl", icon: "🍉", category: "Fruits", serving: "1 bowl", calories: 120, protein: 1.5, carbs: 30, fat: 0.4 },
  { name: "Yogurt (Curd)", icon: "🥣", category: "Snacks", serving: "1 cup", calories: 150, protein: 8, carbs: 11, fat: 8 },
  { name: "Milk", icon: "🥛", category: "Snacks", serving: "1 glass (250ml)", calories: 150, protein: 8, carbs: 12, fat: 8 },
  { name: "Mixed Nuts", icon: "🥜", category: "Snacks", serving: "30g", calories: 175, protein: 6, carbs: 6, fat: 15 },
  { name: "Grilled Sandwich", icon: "🥪", category: "Lunch", serving: "1 sandwich", calories: 280, protein: 10, carbs: 35, fat: 10 },
  { name: "Dal (Lentils)", icon: "🍲", category: "Lunch", serving: "1 bowl", calories: 180, protein: 9, carbs: 27, fat: 4 },
  { name: "Vegetable Soup", icon: "🍜", category: "Dinner", serving: "1 bowl", calories: 90, protein: 3, carbs: 14, fat: 2 },
];

const FOOD_CATEGORIES = ["All", "Breakfast", "Lunch", "Dinner", "Snacks", "Fruits", "Vegetables", "Protein", "Grains"];
