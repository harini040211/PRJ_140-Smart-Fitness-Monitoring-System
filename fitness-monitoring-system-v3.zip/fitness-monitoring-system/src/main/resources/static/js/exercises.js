// Exercise library with MET values (Metabolic Equivalent of Task).
// Calories burned = MET x 3.5 x weight(kg) / 200 x duration(minutes)
// This matches the standard MET-based estimation formula.
const EXERCISES = [
  { name: "Walking", icon: "🚶", muscle: "Full Body", difficulty: "Beginner", equipment: "None", met: 3.5, recommendedMin: 30 },
  { name: "Running", icon: "🏃", muscle: "Full Body", difficulty: "Intermediate", equipment: "None", met: 8.0, recommendedMin: 25 },
  { name: "Cycling", icon: "🚴", muscle: "Legs", difficulty: "Beginner", equipment: "Bicycle", met: 7.0, recommendedMin: 30 },
  { name: "Jogging", icon: "🏃‍♀️", muscle: "Full Body", difficulty: "Beginner", equipment: "None", met: 7.0, recommendedMin: 25 },
  { name: "Squats", icon: "🏋️", muscle: "Legs", difficulty: "Beginner", equipment: "None", met: 5.0, recommendedMin: 10 },
  { name: "Push Ups", icon: "💪", muscle: "Chest", difficulty: "Beginner", equipment: "None", met: 4.0, recommendedMin: 10 },
  { name: "Lunges", icon: "🦵", muscle: "Legs", difficulty: "Beginner", equipment: "None", met: 4.5, recommendedMin: 10 },
  { name: "Plank", icon: "🧘", muscle: "Core", difficulty: "Beginner", equipment: "None", met: 3.8, recommendedMin: 5 },
  { name: "Jumping Jacks", icon: "🤸", muscle: "Full Body", difficulty: "Beginner", equipment: "None", met: 8.0, recommendedMin: 10 },
  { name: "Burpees", icon: "🔥", muscle: "Full Body", difficulty: "Advanced", equipment: "None", met: 8.0, recommendedMin: 10 },
  { name: "Mountain Climbers", icon: "⛰️", muscle: "Core", difficulty: "Intermediate", equipment: "None", met: 8.0, recommendedMin: 10 },
  { name: "Bench Press", icon: "🏋️‍♂️", muscle: "Chest", difficulty: "Intermediate", equipment: "Barbell", met: 5.0, recommendedMin: 15 },
  { name: "Shoulder Press", icon: "🏋️‍♀️", muscle: "Shoulders", difficulty: "Intermediate", equipment: "Dumbbells", met: 4.5, recommendedMin: 15 },
  { name: "Bicep Curl", icon: "💪", muscle: "Arms", difficulty: "Beginner", equipment: "Dumbbells", met: 3.5, recommendedMin: 10 },
  { name: "Tricep Extension", icon: "💪", muscle: "Arms", difficulty: "Beginner", equipment: "Dumbbells", met: 3.5, recommendedMin: 10 },
  { name: "Leg Press", icon: "🦵", muscle: "Legs", difficulty: "Intermediate", equipment: "Machine", met: 5.0, recommendedMin: 15 },
  { name: "Leg Raise", icon: "🦵", muscle: "Core", difficulty: "Beginner", equipment: "None", met: 3.5, recommendedMin: 10 },
  { name: "Yoga", icon: "🧘‍♀️", muscle: "Full Body", difficulty: "Beginner", equipment: "Mat", met: 2.5, recommendedMin: 30 },
  { name: "Swimming", icon: "🏊", muscle: "Full Body", difficulty: "Intermediate", equipment: "Pool", met: 7.0, recommendedMin: 30 },
];

// Intensity nudges the MET-based estimate up or down slightly.
const INTENSITY_FACTOR = { Low: 0.85, Medium: 1.0, High: 1.2 };

function estimateCalories(met, weightKg, durationMinutes, intensity) {
  const factor = INTENSITY_FACTOR[intensity] || 1.0;
  const calories = met * 3.5 * weightKg / 200 * durationMinutes * factor;
  return Math.round(calories * 10) / 10;
}
