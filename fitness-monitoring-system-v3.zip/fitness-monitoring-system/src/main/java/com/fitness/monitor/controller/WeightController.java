package com.fitness.monitor.controller;

import com.fitness.monitor.dto.ApiResponse;
import com.fitness.monitor.dto.WeightRequest;
import com.fitness.monitor.model.WeightRecord;
import com.fitness.monitor.service.WeightService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/weight")
public class WeightController {

    private final WeightService weightService;

    public WeightController(WeightService weightService) {
        this.weightService = weightService;
    }

    @PostMapping
    public ResponseEntity<ApiResponse<WeightRecord>> log(@RequestBody WeightRequest request) {
        return ResponseEntity.ok(ApiResponse.ok("Weight logged", weightService.log(request)));
    }

    @GetMapping("/{userId}")
    public ResponseEntity<ApiResponse<List<WeightRecord>>> history(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.ok("Weight history fetched", weightService.history(userId)));
    }
}
