package com.fitness.monitor.model;

import jakarta.persistence.*;
import java.time.LocalDate;

/**
 * One logged meal entry. Now stores full macros (protein/carbs/fat), all
 * calculated by the frontend food database from the selected food + portion
 * count - the user never types a calorie/macro number by hand.
 */
@Entity
@Table(name = "meals")
public class Meal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long userId;

    private String foodName;
    private String mealType;
    private double servings = 1;
    private double calories;
    private double protein;
    private double carbs;
    private double fat;
    private LocalDate date = LocalDate.now();

    public Meal() {}

    public Meal(Long userId, String foodName, String mealType, double servings,
                double calories, double protein, double carbs, double fat) {
        this.userId = userId;
        this.foodName = foodName;
        this.mealType = mealType;
        this.servings = servings;
        this.calories = calories;
        this.protein = protein;
        this.carbs = carbs;
        this.fat = fat;
    }

    // ---- Getters & Setters ----
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getFoodName() { return foodName; }
    public void setFoodName(String foodName) { this.foodName = foodName; }
    public String getMealType() { return mealType; }
    public void setMealType(String mealType) { this.mealType = mealType; }
    public double getServings() { return servings; }
    public void setServings(double servings) { this.servings = servings; }
    public double getCalories() { return calories; }
    public void setCalories(double calories) { this.calories = calories; }
    public double getProtein() { return protein; }
    public void setProtein(double protein) { this.protein = protein; }
    public double getCarbs() { return carbs; }
    public void setCarbs(double carbs) { this.carbs = carbs; }
    public double getFat() { return fat; }
    public void setFat(double fat) { this.fat = fat; }
    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }
}
