package com.fitness.monitor.service;

import com.fitness.monitor.dto.WaterRequest;
import com.fitness.monitor.model.WaterLog;
import com.fitness.monitor.repository.WaterLogRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Service
public class WaterService {

    private final WaterLogRepository repository;

    public WaterService(WaterLogRepository repository) {
        this.repository = repository;
    }

    public WaterLog add(WaterRequest request) {
        return repository.save(new WaterLog(request.getUserId(), request.getAmountMl()));
    }

    public Map<String, Object> today(Long userId) {
        int total = repository.findByUserIdAndDate(userId, LocalDate.now())
                .stream().mapToInt(WaterLog::getAmountMl).sum();
        return Map.of("date", LocalDate.now().toString(), "totalMl", total);
    }

    public List<WaterLog> history(Long userId) {
        return repository.findByUserIdOrderByDateDesc(userId);
    }
}
