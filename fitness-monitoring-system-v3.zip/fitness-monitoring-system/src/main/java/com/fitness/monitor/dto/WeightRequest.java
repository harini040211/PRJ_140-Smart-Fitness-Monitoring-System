package com.fitness.monitor.dto;

public class WeightRequest {
    private Long userId;
    private double weightKg;

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public double getWeightKg() { return weightKg; }
    public void setWeightKg(double weightKg) { this.weightKg = weightKg; }
}
