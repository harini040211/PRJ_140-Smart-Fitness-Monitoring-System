package com.fitness.monitor.service;

import com.fitness.monitor.model.*;
import com.fitness.monitor.repository.MealRepository;
import com.fitness.monitor.repository.WaterLogRepository;
import com.fitness.monitor.repository.WeightRecordRepository;
import com.fitness.monitor.repository.WorkoutRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;

/**
 * Aggregates every table into the numbers the dashboard needs: today's
 * calorie balance, macro progress against the profile's calculated target,
 * a 7-day workout trend, weight history, water progress, weekly totals,
 * and a small set of achievements unlocked from real activity counts.
 */
@Service
public class DashboardService {

    private final ProfileService profileService;
    private final WorkoutRepository workoutRepository;
    private final MealRepository mealRepository;
    private final WeightRecordRepository weightRepository;
    private final WaterLogRepository waterRepository;

    public DashboardService(ProfileService profileService,
                             WorkoutRepository workoutRepository,
                             MealRepository mealRepository,
                             WeightRecordRepository weightRepository,
                             WaterLogRepository waterRepository) {
        this.profileService = profileService;
        this.workoutRepository = workoutRepository;
        this.mealRepository = mealRepository;
        this.weightRepository = weightRepository;
        this.waterRepository = waterRepository;
    }

    public Map<String, Object> getSummary(Long userId) {
        Profile profile = profileService.getByUserId(userId);
        List<Workout> workouts = workoutRepository.findByUserIdOrderByDateDesc(userId);
        List<Meal> meals = mealRepository.findByUserIdOrderByDateDesc(userId);
        List<WeightRecord> weights = weightRepository.findByUserIdOrderByDateAsc(userId);

        LocalDate today = LocalDate.now();

        double caloriesBurnedToday = workouts.stream().filter(w -> w.getDate().equals(today))
                .mapToDouble(Workout::getCaloriesBurned).sum();
        double caloriesEatenToday = meals.stream().filter(m -> m.getDate().equals(today))
                .mapToDouble(Meal::getCalories).sum();
        double proteinToday = meals.stream().filter(m -> m.getDate().equals(today)).mapToDouble(Meal::getProtein).sum();
        double carbsToday = meals.stream().filter(m -> m.getDate().equals(today)).mapToDouble(Meal::getCarbs).sum();
        double fatToday = meals.stream().filter(m -> m.getDate().equals(today)).mapToDouble(Meal::getFat).sum();
        int workoutMinutesToday = workouts.stream().filter(w -> w.getDate().equals(today))
                .mapToInt(Workout::getDurationMinutes).sum();

        // Macro targets derived from the calorie target (30% protein / 45% carbs / 25% fat)
        double proteinTargetG = (profile.getCalorieTarget() * 0.30) / 4.0;
        double carbsTargetG = (profile.getCalorieTarget() * 0.45) / 4.0;
        double fatTargetG = (profile.getCalorieTarget() * 0.25) / 9.0;

        Workout lastWorkout = workouts.isEmpty() ? null : workouts.get(0);
        Meal lastMeal = meals.isEmpty() ? null : meals.get(0);

        // ---- 7-day calories-burned trend ----
        LinkedHashMap<LocalDate, Double> burnedByDay = new LinkedHashMap<>();
        for (int i = 6; i >= 0; i--) burnedByDay.put(today.minusDays(i), 0.0);
        for (Workout w : workouts) if (burnedByDay.containsKey(w.getDate())) burnedByDay.merge(w.getDate(), w.getCaloriesBurned(), Double::sum);
        List<Map<String, Object>> weeklyTrend = new ArrayList<>();
        burnedByDay.forEach((d, c) -> weeklyTrend.add(Map.of("date", d.toString(), "caloriesBurned", c)));

        // ---- This week's totals (Mon-Sun of current week) ----
        LocalDate weekStart = today.minusDays(today.getDayOfWeek().getValue() - 1);
        int weeklyWorkoutCount = (int) workouts.stream().filter(w -> !w.getDate().isBefore(weekStart)).count();
        int weeklyMinutes = workouts.stream().filter(w -> !w.getDate().isBefore(weekStart)).mapToInt(Workout::getDurationMinutes).sum();
        double weeklyCaloriesBurned = workouts.stream().filter(w -> !w.getDate().isBefore(weekStart)).mapToDouble(Workout::getCaloriesBurned).sum();

        // ---- Weight progress ----
        Double startingWeight = weights.isEmpty() ? null : weights.get(0).getWeightKg();
        Double currentWeight = weights.isEmpty() ? profile.getWeightKg() : weights.get(weights.size() - 1).getWeightKg();
        List<Map<String, Object>> weightHistory = weights.stream()
                .map(w -> (Map<String, Object>) Map.<String, Object>of("date", w.getDate().toString(), "weightKg", w.getWeightKg()))
                .toList();
        Double weightProgressPct = null;
        if (startingWeight != null && profile.getTargetWeightKg() != null && !startingWeight.equals(profile.getTargetWeightKg())) {
            double totalChange = startingWeight - profile.getTargetWeightKg();
            double doneSoFar = startingWeight - currentWeight;
            weightProgressPct = Math.max(0, Math.min(100, Math.round((doneSoFar / totalChange) * 1000.0) / 10.0));
        }

        // ---- Water today ----
        int waterTodayMl = waterRepository.findByUserIdAndDate(userId, today).stream().mapToInt(WaterLog::getAmountMl).sum();

        // ---- Achievements (derived from real counts, not hardcoded) ----
        double totalCaloriesBurnedAllTime = workouts.stream().mapToDouble(Workout::getCaloriesBurned).sum();
        List<Map<String, Object>> achievements = List.of(
                achievement("First Workout", "\uD83C\uDFC3", !workouts.isEmpty()),
                achievement("5 Workouts Completed", "\uD83D\uDCAA", workouts.size() >= 5),
                achievement("1,000 kcal Burned", "\uD83D\uDD25", totalCaloriesBurnedAllTime >= 1000),
                achievement("First Meal Logged", "\uD83C\uDF4E", !meals.isEmpty()),
                achievement("Profile Completed", "\u2705", true)
        );

        Map<String, Object> summary = new HashMap<>();
        summary.put("bmi", profile.getBmi());
        summary.put("bmiCategory", profile.getBmiCategory());
        summary.put("bmr", profile.getBmr());
        summary.put("tdee", profile.getTdee());
        summary.put("calorieTarget", profile.getCalorieTarget());
        summary.put("caloriesBurnedToday", caloriesBurnedToday);
        summary.put("caloriesEatenToday", caloriesEatenToday);
        summary.put("netCalories", caloriesEatenToday - caloriesBurnedToday);
        summary.put("remainingCalories", profile.getCalorieTarget() - caloriesEatenToday + caloriesBurnedToday);
        summary.put("proteinToday", round(proteinToday));
        summary.put("carbsToday", round(carbsToday));
        summary.put("fatToday", round(fatToday));
        summary.put("proteinTargetG", round(proteinTargetG));
        summary.put("carbsTargetG", round(carbsTargetG));
        summary.put("fatTargetG", round(fatTargetG));
        summary.put("workoutMinutesToday", workoutMinutesToday);
        summary.put("totalWorkoutsLogged", workouts.size());
        summary.put("totalMealsLogged", meals.size());
        summary.put("lastWorkout", lastWorkout);
        summary.put("lastMeal", lastMeal);
        summary.put("weeklyTrend", weeklyTrend);
        summary.put("weeklyWorkoutCount", weeklyWorkoutCount);
        summary.put("weeklyWorkoutGoal", profile.getWeeklyWorkoutGoal());
        summary.put("weeklyMinutes", weeklyMinutes);
        summary.put("weeklyCaloriesBurned", weeklyCaloriesBurned);
        summary.put("startingWeight", startingWeight);
        summary.put("currentWeight", currentWeight);
        summary.put("targetWeight", profile.getTargetWeightKg());
        summary.put("weightProgressPct", weightProgressPct);
        summary.put("weightHistory", weightHistory);
        summary.put("waterTodayMl", waterTodayMl);
        summary.put("waterGoalMl", profile.getDailyWaterGoalMl());
        summary.put("achievements", achievements);
        return summary;
    }

    private Map<String, Object> achievement(String name, String icon, boolean unlocked) {
        return Map.of("name", name, "icon", icon, "unlocked", unlocked);
    }

    private double round(double v) {
        return Math.round(v * 10.0) / 10.0;
    }
}
