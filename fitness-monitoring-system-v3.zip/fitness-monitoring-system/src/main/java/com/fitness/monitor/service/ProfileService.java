package com.fitness.monitor.service;

import com.fitness.monitor.dto.ProfileRequest;
import com.fitness.monitor.model.Profile;
import com.fitness.monitor.repository.ProfileRepository;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * Owns the profile record and all the derived numbers - BMI, BMR, TDEE,
 * and the daily calorie target. None of these are typed in by the user;
 * they are calculated here from age/height/weight/activity/goal.
 */
@Service
public class ProfileService {

    private final ProfileRepository profileRepository;
    private final BmiService bmiService;

    // Activity level -> TDEE multiplier (standard Harris-Benedict activity factors)
    private static final Map<String, Double> ACTIVITY_MULTIPLIER = new HashMap<>();
    static {
        ACTIVITY_MULTIPLIER.put("Sedentary", 1.2);
        ACTIVITY_MULTIPLIER.put("Lightly Active", 1.375);
        ACTIVITY_MULTIPLIER.put("Moderately Active", 1.55);
        ACTIVITY_MULTIPLIER.put("Very Active", 1.725);
    }

    public ProfileService(ProfileRepository profileRepository, BmiService bmiService) {
        this.profileRepository = profileRepository;
        this.bmiService = bmiService;
    }

    public Profile saveOrUpdate(ProfileRequest request) {
        Profile profile = profileRepository.findByUserId(request.getUserId())
                .orElse(new Profile());

        profile.setUserId(request.getUserId());
        profile.setAge(request.getAge());
        profile.setGender(request.getGender());
        profile.setHeightCm(request.getHeightCm());
        profile.setWeightKg(request.getWeightKg());
        profile.setActivityLevel(request.getActivityLevel());
        profile.setFitnessGoal(request.getFitnessGoal());
        profile.setTargetWeightKg(request.getTargetWeightKg());
        if (request.getWeeklyWorkoutGoal() != null) profile.setWeeklyWorkoutGoal(request.getWeeklyWorkoutGoal());
        if (request.getDailyWaterGoalMl() != null) profile.setDailyWaterGoalMl(request.getDailyWaterGoalMl());

        // ---- BMI (unchanged formula) ----
        double bmi = bmiService.calculateBmi(request.getWeightKg(), request.getHeightCm());
        profile.setBmi(bmi);
        profile.setBmiCategory(bmiService.classify(bmi));

        // ---- BMR: Mifflin-St Jeor equation ----
        double bmr;
        if ("Female".equalsIgnoreCase(request.getGender())) {
            bmr = (10 * request.getWeightKg()) + (6.25 * request.getHeightCm()) - (5 * request.getAge()) - 161;
        } else {
            bmr = (10 * request.getWeightKg()) + (6.25 * request.getHeightCm()) - (5 * request.getAge()) + 5;
        }
        profile.setBmr(round(bmr));

        // ---- TDEE: BMR x activity multiplier ----
        double multiplier = ACTIVITY_MULTIPLIER.getOrDefault(request.getActivityLevel(), 1.375);
        double tdee = bmr * multiplier;
        profile.setTdee(round(tdee));

        // ---- Calorie target: adjust TDEE based on the stated goal ----
        double target;
        String goal = request.getFitnessGoal() == null ? "" : request.getFitnessGoal();
        switch (goal) {
            case "Weight Loss" -> target = tdee - 500;   // ~0.5kg/week deficit
            case "Weight Gain" -> target = tdee + 400;
            case "Muscle Gain" -> target = tdee + 250;
            default -> target = tdee;                     // Maintenance / General Fitness
        }
        profile.setCalorieTarget(round(target));

        return profileRepository.save(profile);
    }

    public Profile getByUserId(Long userId) {
        return profileRepository.findByUserId(userId)
                .orElseThrow(() -> new IllegalArgumentException("Profile not found. Please complete your profile first."));
    }

    private double round(double v) {
        return Math.round(v * 10.0) / 10.0;
    }
}
