package com.fitness.monitor.controller;

import com.fitness.monitor.dto.ApiResponse;
import com.fitness.monitor.dto.WorkoutRequest;
import com.fitness.monitor.model.Workout;
import com.fitness.monitor.service.WorkoutService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/workouts")
public class WorkoutController {

    private final WorkoutService workoutService;

    public WorkoutController(WorkoutService workoutService) {
        this.workoutService = workoutService;
    }

    @PostMapping
    public ResponseEntity<ApiResponse<Workout>> logWorkout(@RequestBody WorkoutRequest request) {
        Workout workout = workoutService.logWorkout(request);
        return ResponseEntity.ok(ApiResponse.ok("Workout logged", workout));
    }

    @GetMapping("/{userId}")
    public ResponseEntity<ApiResponse<List<Workout>>> getHistory(@PathVariable Long userId) {
        List<Workout> history = workoutService.getHistory(userId);
        return ResponseEntity.ok(ApiResponse.ok("Workout history fetched", history));
    }

    @DeleteMapping("/{workoutId}")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long workoutId) {
        workoutService.delete(workoutId);
        return ResponseEntity.ok(ApiResponse.ok("Workout deleted", null));
    }
}
