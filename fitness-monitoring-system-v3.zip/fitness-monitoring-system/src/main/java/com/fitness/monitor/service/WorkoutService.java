package com.fitness.monitor.service;

import com.fitness.monitor.dto.WorkoutRequest;
import com.fitness.monitor.model.Profile;
import com.fitness.monitor.model.Workout;
import com.fitness.monitor.repository.WorkoutRepository;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Logs workouts and estimates calories burned using the MET formula:
 *   calories = MET x weight(kg) x duration(hours) x intensity multiplier
 */
@Service
public class WorkoutService {

    private final WorkoutRepository workoutRepository;
    private final ProfileService profileService;

    // Kept in sync with the exercise library in static/js/exercises.js
    private static final Map<String, Double> MET_VALUES = new HashMap<>();
    static {
        MET_VALUES.put("Walking", 3.5);
        MET_VALUES.put("Running", 8.0);
        MET_VALUES.put("Cycling", 7.0);
        MET_VALUES.put("Jogging", 7.0);
        MET_VALUES.put("Squats", 5.0);
        MET_VALUES.put("Push Ups", 4.0);
        MET_VALUES.put("Lunges", 4.5);
        MET_VALUES.put("Plank", 3.8);
        MET_VALUES.put("Jumping Jacks", 8.0);
        MET_VALUES.put("Burpees", 8.0);
        MET_VALUES.put("Mountain Climbers", 8.0);
        MET_VALUES.put("Bench Press", 5.0);
        MET_VALUES.put("Shoulder Press", 4.5);
        MET_VALUES.put("Bicep Curl", 3.5);
        MET_VALUES.put("Tricep Extension", 3.5);
        MET_VALUES.put("Leg Press", 5.0);
        MET_VALUES.put("Leg Raise", 3.5);
        MET_VALUES.put("Yoga", 2.5);
        MET_VALUES.put("Swimming", 7.0);
        MET_VALUES.put("Gym / Weight Training", 5.0);
    }

    // Extra feature: intensity nudges the calorie estimate up/down slightly
    private static final Map<String, Double> INTENSITY_MULTIPLIER = new HashMap<>();
    static {
        INTENSITY_MULTIPLIER.put("Low", 0.85);
        INTENSITY_MULTIPLIER.put("Medium", 1.0);
        INTENSITY_MULTIPLIER.put("High", 1.2);
    }

    public WorkoutService(WorkoutRepository workoutRepository, ProfileService profileService) {
        this.workoutRepository = workoutRepository;
        this.profileService = profileService;
    }

    public Workout logWorkout(WorkoutRequest request) {
        Profile profile = profileService.getByUserId(request.getUserId());

        double met = MET_VALUES.getOrDefault(request.getExerciseType(), 4.0);
        double intensityFactor = INTENSITY_MULTIPLIER.getOrDefault(request.getIntensity(), 1.0);
        double hours = request.getDurationMinutes() / 60.0;
        double calories = met * profile.getWeightKg() * hours * intensityFactor;

        Workout workout = new Workout(request.getUserId(), request.getExerciseType(),
                request.getIntensity(), request.getDurationMinutes());
        workout.setCaloriesBurned(Math.round(calories * 10.0) / 10.0);

        return workoutRepository.save(workout);
    }

    public List<Workout> getHistory(Long userId) {
        return workoutRepository.findByUserIdOrderByDateDesc(userId);
    }

    public void delete(Long workoutId) {
        workoutRepository.deleteById(workoutId);
    }
}
