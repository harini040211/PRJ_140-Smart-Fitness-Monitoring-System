package com.fitness.monitor.service;

import com.fitness.monitor.dto.MealRequest;
import com.fitness.monitor.model.Meal;
import com.fitness.monitor.repository.MealRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MealService {

    private final MealRepository mealRepository;

    public MealService(MealRepository mealRepository) {
        this.mealRepository = mealRepository;
    }

    /** Calories/macros arrive already computed by the frontend food database x servings. */
    public Meal logMeal(MealRequest request) {
        Meal meal = new Meal(request.getUserId(), request.getFoodName(), request.getMealType(),
                request.getServings(), request.getCalories(), request.getProtein(),
                request.getCarbs(), request.getFat());
        return mealRepository.save(meal);
    }

    public List<Meal> getHistory(Long userId) {
        return mealRepository.findByUserIdOrderByDateDesc(userId);
    }

    public void delete(Long mealId) {
        mealRepository.deleteById(mealId);
    }
}
