package com.fitness.monitor.service;

import com.fitness.monitor.dto.WeightRequest;
import com.fitness.monitor.model.WeightRecord;
import com.fitness.monitor.repository.WeightRecordRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WeightService {

    private final WeightRecordRepository repository;

    public WeightService(WeightRecordRepository repository) {
        this.repository = repository;
    }

    public WeightRecord log(WeightRequest request) {
        return repository.save(new WeightRecord(request.getUserId(), request.getWeightKg()));
    }

    public List<WeightRecord> history(Long userId) {
        return repository.findByUserIdOrderByDateAsc(userId);
    }
}
