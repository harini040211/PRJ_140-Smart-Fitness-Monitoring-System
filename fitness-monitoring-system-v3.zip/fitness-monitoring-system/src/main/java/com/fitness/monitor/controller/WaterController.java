package com.fitness.monitor.controller;

import com.fitness.monitor.dto.ApiResponse;
import com.fitness.monitor.dto.WaterRequest;
import com.fitness.monitor.model.WaterLog;
import com.fitness.monitor.service.WaterService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/water")
public class WaterController {

    private final WaterService waterService;

    public WaterController(WaterService waterService) {
        this.waterService = waterService;
    }

    @PostMapping
    public ResponseEntity<ApiResponse<WaterLog>> add(@RequestBody WaterRequest request) {
        return ResponseEntity.ok(ApiResponse.ok("Water logged", waterService.add(request)));
    }

    @GetMapping("/{userId}/today")
    public ResponseEntity<ApiResponse<Map<String, Object>>> today(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.ok("Today's water fetched", waterService.today(userId)));
    }
}
