package com.fitness.monitor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Entry point for the Fitness Monitoring System backend.
 * Run this class (or `mvn spring-boot:run`) to start the server on port 8080.
 */
@SpringBootApplication
public class FitnessMonitoringApplication {
    public static void main(String[] args) {
        SpringApplication.run(FitnessMonitoringApplication.class, args);
    }
}
