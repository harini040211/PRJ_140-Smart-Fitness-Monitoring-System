package com.fitness.monitor.controller;

import com.fitness.monitor.dto.ApiResponse;
import com.fitness.monitor.dto.ProfileRequest;
import com.fitness.monitor.model.Profile;
import com.fitness.monitor.service.ProfileService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/profile")
public class ProfileController {

    private final ProfileService profileService;

    public ProfileController(ProfileService profileService) {
        this.profileService = profileService;
    }

    @PostMapping
    public ResponseEntity<ApiResponse<Profile>> saveProfile(@RequestBody ProfileRequest request) {
        Profile profile = profileService.saveOrUpdate(request);
        return ResponseEntity.ok(ApiResponse.ok("Profile saved. BMI calculated.", profile));
    }

    @GetMapping("/{userId}")
    public ResponseEntity<ApiResponse<Profile>> getProfile(@PathVariable Long userId) {
        Profile profile = profileService.getByUserId(userId);
        return ResponseEntity.ok(ApiResponse.ok("Profile fetched", profile));
    }
}
