package com.fitness.monitor.service;

import org.springframework.stereotype.Service;

/**
 * Calculates BMI using the standard formula:
 *   BMI = weight(kg) / (height(m))^2
 * and classifies it into the standard WHO categories.
 */
@Service
public class BmiService {

    public double calculateBmi(double weightKg, double heightCm) {
        double heightM = heightCm / 100.0;
        double bmi = weightKg / (heightM * heightM);
        return Math.round(bmi * 10.0) / 10.0; // round to 1 decimal
    }

    public String classify(double bmi) {
        if (bmi < 18.5) return "Underweight";
        if (bmi < 25)   return "Normal";
        if (bmi < 30)   return "Overweight";
        return "Obese";
    }
}
