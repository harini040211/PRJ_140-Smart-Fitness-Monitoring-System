package com.fitness.monitor.controller;

import com.fitness.monitor.dto.ApiResponse;
import com.fitness.monitor.dto.MealRequest;
import com.fitness.monitor.model.Meal;
import com.fitness.monitor.service.MealService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/meals")
public class MealController {

    private final MealService mealService;

    public MealController(MealService mealService) {
        this.mealService = mealService;
    }

    @PostMapping
    public ResponseEntity<ApiResponse<Meal>> logMeal(@RequestBody MealRequest request) {
        return ResponseEntity.ok(ApiResponse.ok("Meal logged", mealService.logMeal(request)));
    }

    @GetMapping("/{userId}")
    public ResponseEntity<ApiResponse<List<Meal>>> getHistory(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.ok("Meal history fetched", mealService.getHistory(userId)));
    }

    @DeleteMapping("/{mealId}")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long mealId) {
        mealService.delete(mealId);
        return ResponseEntity.ok(ApiResponse.ok("Meal deleted", null));
    }
}
