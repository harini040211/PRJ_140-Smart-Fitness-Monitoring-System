package com.fitness.monitor.dto;

public class WaterRequest {
    private Long userId;
    private int amountMl;

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public int getAmountMl() { return amountMl; }
    public void setAmountMl(int amountMl) { this.amountMl = amountMl; }
}
